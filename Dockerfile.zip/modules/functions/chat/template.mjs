/*
    Just a copy/paste file template.
 */
import {serverconfig, fetch} from "../../index.mjs"
