git clone git@github.com:hackthedev/dcts-shipping.git
cp -rf $PWD/dcts-shipping/* $PWD
rm -rf $PWD/dcts-shipping