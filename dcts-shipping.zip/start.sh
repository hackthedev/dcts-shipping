screen -dmSL dcts node /home/dcts
