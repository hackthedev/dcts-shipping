//const colors = require("colors");

module.exports = function(socket) {

}